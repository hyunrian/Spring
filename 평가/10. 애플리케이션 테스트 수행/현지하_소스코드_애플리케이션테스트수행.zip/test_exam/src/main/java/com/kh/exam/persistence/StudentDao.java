package com.kh.exam.persistence;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.exam.domain.StudentVo;

@Repository
public class StudentDao {
	
	@Autowired
	SqlSession sqlSession;
	
	public boolean insert(StudentVo vo) {
		int count = sqlSession.insert("mymapper.insert", vo);
		if (count == 1) return true;
		return false;
	}
	
	public List<StudentVo> selectAll() {
		return sqlSession.selectList("mymapper.selectAll");
	}
	
	public StudentVo selectOne(String sno) {
		return sqlSession.selectOne("mymapper.selectOne", sno);
	}
	
	public boolean update(StudentVo vo) {
		int count = sqlSession.update("mymapper.update", vo);
		if (count == 1) return true;
		return false;
	}
	
	public boolean delete(String sno) {
		int count = sqlSession.delete("mymapper.delete", sno);
		if (count == 1) return true;
		return false;
	}

}
