package com.kh.exam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.exam.domain.StudentVo;
import com.kh.exam.persistence.StudentDao;

@Service
public class StudentService {
	
	@Autowired
	StudentDao dao;
	
	public boolean insert(StudentVo vo) {
		boolean result = dao.insert(vo);
		if (result) return true;
		return false;
	}
	
	public List<StudentVo> selectAll() {
		return dao.selectAll();
	}
	
	public StudentVo selectOne(String sno) {
		return dao.selectOne(sno);
	}
	
	public boolean update(StudentVo vo) {
		boolean result = dao.update(vo);
		if (result) return true;
		return false;
	}
	
	public boolean delete(String sno) {
		boolean result = dao.delete(sno);
		if (result) return true;
		return false;
	}

}
