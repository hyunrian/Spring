package com.kh.exam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kh.exam.domain.StudentVo;
import com.kh.exam.service.StudentService;

@RequestMapping(value = "/student")
@RestController
public class StudentController {
	
	@Autowired
	StudentService service;
	
	// 학생 목록
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<StudentVo> selectAll(Model model) {
		return service.selectAll();
	}
	
	// 학생 등록
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String insert(@RequestBody StudentVo vo) {
		boolean result = service.insert(vo);
		if (result) return "SUCCESS";
		return "FAIL";
	}
	
	// 학생 삭제
	@RequestMapping(value = "/del/{sno}", method = RequestMethod.DELETE)
	public String delete(@PathVariable String sno) {
		boolean result = service.delete(sno);
		if (result) return "SUCCESS";
		return "FAIL";
	}
	
	// 학생 수정
	@RequestMapping(value = "/mod", method = RequestMethod.PATCH)
	public String update(@RequestBody StudentVo vo) {
		boolean result = service.update(vo);
		if (result) return "SUCCESS";
		return "FAIL";
	}
	
//	@RequestMapping(value = "/update", method = RequestMethod.GET)
//	public String read(String sno, Model model) {
//		StudentVo vo = service.selectOne(sno);
//		model.addAttribute("vo", vo);
//		return "student/update";
//	}
	
}
