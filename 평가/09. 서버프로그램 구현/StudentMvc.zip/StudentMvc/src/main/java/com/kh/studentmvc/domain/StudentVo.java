package com.kh.studentmvc.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class StudentVo {
	
	private String sno;
	private String sname;
	private int syear;
	private String gender;
	private String major;
	private int score;
	
	public StudentVo(String sno, String sname, int syear, String gender, String major) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.syear = syear;
		this.gender = gender;
		this.major = major;
	}

	
}
