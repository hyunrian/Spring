package com.kh.studentmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kh.studentmvc.domain.StudentVo;
import com.kh.studentmvc.service.StudentService;

@RequestMapping(value = "/student")
@Controller
public class StudentController {
	
	@Autowired
	StudentService service;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String selectAll(Model model) {
		
		List<StudentVo> list = service.selectAll();
		model.addAttribute("list", list);
		
		return "student/list";
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public String insert() {
		return "student/insert";
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insert(StudentVo vo) {
		System.out.println("insert 처리");
		System.out.println("vo: " + vo);
		service.insert(vo);
		return "redirect:/student/list";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(String sno) {
		service.delete(sno);
		return "redirect:/student/list";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String read(String sno, Model model) {
		StudentVo vo = service.selectOne(sno);
		model.addAttribute("vo", vo);
		return "student/update";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String update(StudentVo vo) {
		service.update(vo);
		return "redirect:/student/list";
	}
	
	
	
	
	

}
