package com.kh.studentmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.studentmvc.domain.StudentVo;
import com.kh.studentmvc.persistence.StudentDao;

@Service
public class StudentService {
	
	@Autowired
	StudentDao dao;
	
	public void insert(StudentVo vo) {
		dao.insert(vo);
	}
	
	public List<StudentVo> selectAll() {
		return dao.selectAll();
	}
	
	public StudentVo selectOne(String sno) {
		return dao.selectOne(sno);
	}
	
	public void update(StudentVo vo) {
		dao.update(vo);
	}
	
	public void delete(String sno) {
		dao.delete(sno);
	}

}
