package com.kh.studentmvc.persistence;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.studentmvc.domain.StudentVo;

@Repository
public class StudentDao {
	
	@Autowired
	SqlSession sqlSession;
	
	public void insert(StudentVo vo) {
		sqlSession.insert("mymapper.insert", vo);
	}
	
	public List<StudentVo> selectAll() {
		return sqlSession.selectList("mymapper.selectAll");
	}
	
	public StudentVo selectOne(String sno) {
		return sqlSession.selectOne("mymapper.selectOne", sno);
	}
	
	public void update(StudentVo vo) {
		sqlSession.update("mymapper.update", vo);
	}
	
	public void delete(String sno) {
		sqlSession.delete("mymapper.delete", sno);
	}

}
