package com.kh.studentmvc;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.kh.studentmvc.domain.StudentVo;
import com.kh.studentmvc.persistence.StudentDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = 
	{"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class StudentDaoTest {

	@Autowired
	StudentDao dao;
	
	@Test
	public void testInsert() {
		StudentVo vo = new StudentVo("2222", "색연필", 2, "M", "피아노", 88);
		dao.insert(vo);
	}
	
	@Test
	public void testSelectAll() {
		List<StudentVo> list = dao.selectAll();
		System.out.println("list: " + list);
	}
	
	@Test
	public void testUpdate() {
		StudentVo vo = dao.selectOne("2222");
		System.out.println("vo: " + vo);
		vo.setSname("테스트");
		vo.setSyear(4);
		vo.setGender("F");
		vo.setMajor("성악");
		vo.setScore(22);
		dao.update(vo);
	}
	
	@Test
	public void testDelete() {
		dao.delete("2222");
	}
	
}
